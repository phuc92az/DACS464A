﻿using System;
using System.Windows;

namespace WPF
{
    public partial class GiaiPTBac2 : Window
    {
        public GiaiPTBac2()
        {
            InitializeComponent();
        }

        private void btnGiai_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                double a = double.Parse(txtA.Text);
                double b = double.Parse(txtB.Text);
                double c = double.Parse(txtC.Text);

                if (a == 0)
                {
                    if (b == 0)
                        txtKetQua.Text = (c == 0) ? "Phương trình vô số nghiệm" : "Phương trình vô nghiệm";
                    else
                        txtKetQua.Text = $"Phương trình có nghiệm: x = {-c / b}";
                }
                else
                {
                    double delta = b * b - 4 * a * c;
                    if (delta < 0)
                        txtKetQua.Text = "Phương trình vô nghiệm";
                    else if (delta == 0)
                        txtKetQua.Text = $"Phương trình có nghiệm kép: x = {-b / (2 * a)}";
                    else
                    {
                        double x1 = (-b + Math.Sqrt(delta)) / (2 * a);
                        double x2 = (-b - Math.Sqrt(delta)) / (2 * a);
                        txtKetQua.Text = $"Phương trình có 2 nghiệm:\n x1 = {x1}\n x2 = {x2}";
                    }
                }
            }
            catch
            {
                MessageBox.Show("Vui lòng nhập số hợp lệ!");
            }
        }
    }
}
